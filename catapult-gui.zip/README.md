# Catapult GUI

A Python graphical user interface (GUI) for the Catapult game, implemented using Tkinter. This program allows players to interact with the game board and pieces through a visual interface.

**Please note:** This program is solely a GUI; it does not incorporate the logic for finding valid moves or enforce game rules.

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [Credits](#credits)

## Installation

1. **Install Anaconda or Miniconda**

   If you don't have Conda installed, download and install it from:

   - [Anaconda Distribution](https://www.anaconda.com/products/individual)
   - [Miniconda](https://docs.conda.io/en/latest/miniconda.html)

2. **Create a New Conda Environment**

   Open your terminal or command prompt and run:

   ```bash
   conda env create -f environment.yaml
   ```

3. **Activate the Environment**

   ```bash
   conda activate catapult-gui
   ```

4. **Navigate to the Project Directory**

   ```bash
   cd catapult-gui
   ```

5. **Place the Executable**:

   - Ensure you have the `catapult` executable file.
   - It can be found in the hidden directory `.stack-work/install/` in your stack project.
   - Place it in a directory of your choice.
   - Update the `EXECUTABLE_PATH` variable in `catapult/logic.py` to point to the correct path.

      ```python
     # In catapult/logic.py
     EXECUTABLE_PATH = "/path/to/your/executable/catapult"
     ```

## Usage

Run the game by executing `main.py`:

```bash
python main.py
```

The game window will appear, and you can start interacting with the game board by dragging and dropping the pieces.

**Note:** Since this program is only a GUI and your Haskell program is responsible for following the game rules.

You can change the displayed board configuration by changing the FEN string in `main.py`:

   ```python
   # In main.py
   initial_board_string = "4W5/1w1w1w1w1w/1w1w1w1w1w/1w1w1w1w1w/5g4/4G5/b1b1b1b1b1/b1b1b1b1b1/b1b1b1b1b1/7B2"
   ```

**Note:** If a player's flag or general is not present on the board, the GUI will automatically assume that the opposing player has won. 
The implementation of flag placement is not yet completed.

- **Developers**: Willie & Chatti
- **Concept**: Catapult by Julian
- **Libraries Used**:
  - [Tkinter](https://docs.python.org/3/library/tkinter.html)
  - [Pillow](https://python-pillow.org/)