import tkinter as tk
from catapult.logic import GameLogic
from catapult.board import BoardGUI

if __name__ == "__main__":
    root = tk.Tk()
    initial_board_string = '4W5/1w1w1w1w1w/1w1w1w1w1w/1w1w1w1w1w/5g4/4G5/b1b1b1b1b1/b1b1b1b1b1/b1b1b1b1b1/7B2'
    current_player = 'w'
    game_logic = GameLogic(initial_board_string, current_player)
    chess_board_gui = BoardGUI(root, game_logic)
    root.mainloop()
