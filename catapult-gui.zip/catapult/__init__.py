# catapult/__init__.py

# This file can be left empty or used to set up package-level variables.