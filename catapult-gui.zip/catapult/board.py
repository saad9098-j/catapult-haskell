import tkinter as tk
from PIL import ImageTk, Image
import random
import os

class PieceRenderer:
    def __init__(self, cell_size):
        self.cell_size = cell_size
        self.images = {}
        self.load_images()

    def load_images(self):
        self.images = {
            'B': self.load_image(os.path.join('images', 'black_flag.png')),
            'G': self.load_image(os.path.join('images', 'black_general.png')),
            'b': self.load_image(os.path.join('images', 'black_knight.png')),
            'W': self.load_image(os.path.join('images', 'white_flag.png')),
            'g': self.load_image(os.path.join('images', 'white_general.png')),
            'w': self.load_image(os.path.join('images', 'white_knight.png'))
        }

    def load_image(self, filename):
        try:
            img = Image.open(filename)
            img = img.resize((self.cell_size - 10, self.cell_size - 10), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(img)
        except IOError:
            print(f"Error: Could not load image '{filename}'.")
            return None

    def get_image(self, piece_char):
        return self.images.get(piece_char, None)

class BoardGUI:
    def __init__(self, root, game_logic):
        self.root = root
        self.game_logic = game_logic
        self.canvas = tk.Canvas(root, width=500, height=500)
        self.canvas.pack()
        self.cell_size = 50
        self.pieces = {}
        self.piece_renderer = PieceRenderer(self.cell_size)
        self.highlighted_cells = []

        self.draw_board()
        self.render_board()
        self.add_indices()
        self.update_window_title()

    def update_window_title(self):
        player_full = 'White' if self.game_logic.current_player == 'w' else 'Black'
        self.root.title(f"Catapult - {player_full}'s Turn")

    def draw_board(self):
        # Draw 10x10 board without black lines between fields
        for row in range(10):
            for col in range(10):
                x1 = col * self.cell_size
                y1 = row * self.cell_size
                x2 = x1 + self.cell_size
                y2 = y1 + self.cell_size
                fill_color = "#f0d9b5" if (row + col) % 2 == 0 else "#b58863"
                self.canvas.create_rectangle(x1, y1, x2, y2, fill=fill_color, outline=fill_color)

    def render_board(self):
        # Clear existing pieces
        self.canvas.delete('piece')
        self.pieces.clear()

        # Render pieces based on the current board state
        board = self.game_logic.board
        for row_idx, row in enumerate(board):
            for col_idx, piece_char in enumerate(row):
                if piece_char:
                    image = self.piece_renderer.get_image(piece_char)
                    if image:
                        piece_id = self.draw_piece(row_idx, col_idx, image)
                        self.pieces[piece_id] = (row_idx, col_idx)
                        self.make_draggable(piece_id)

    def draw_piece(self, row, col, image):
        x = col * self.cell_size + self.cell_size / 2
        y = row * self.cell_size + self.cell_size / 2
        return self.canvas.create_image(x, y, image=image, tags='piece')

    def add_indices(self):
        # Add row indices (numbers) starting from 0 in the lowest left cell
        for row in range(10):
            y = (9 - row) * self.cell_size + self.cell_size - 35  # Shift numbers slightly higher
            x = 5
            fill_color = "#b58863" if (9 - row) % 2 == 0 else "#f0d9b5"
            self.canvas.create_text(x, y, text=str(row), font=('Helvetica', 12), anchor='w', fill=fill_color)

        # Add column indices (letters) starting from 'a' in the lower left corner
        for col, letter in enumerate('abcdefghij'):
            x = col * self.cell_size + self.cell_size - 10  # Shift position slightly to the right
            y = 495
            fill_color = "#b58863" if (9 - col) % 2 == 0 else "#f0d9b5"
            self.canvas.create_text(x, y, text=letter, font=('Helvetica', 12), anchor='s', fill=fill_color)

    def make_draggable(self, piece_id):
        def on_drag_start(event):
            if self.game_logic.game_over:
                return
            
            widget = event.widget
            row, col = self.pieces[piece_id]
            self.drag_data = {
                'item': piece_id,
                'start_x': event.x,
                'start_y': event.y,
                'start_row': row,
                'start_col': col
            }
            self.highlight_moves(row, col)
            self.canvas.tag_raise(piece_id)

        def on_drag_motion(event):
            if self.game_logic.game_over:
                return
            
            dx = event.x - self.drag_data['start_x']
            dy = event.y - self.drag_data['start_y']
            self.canvas.move(self.drag_data['item'], dx, dy)
            self.drag_data['start_x'] = event.x
            self.drag_data['start_y'] = event.y

        def on_drag_release(event):
            if self.game_logic.game_over:
                return
            
            item = self.drag_data['item']
            coords = self.canvas.coords(item)
            if len(coords) == 0:
                return
            
            center_x, center_y = coords[:2]
            new_col = int(center_x // self.cell_size)
            new_row = int(center_y // self.cell_size)

            # Ensure new positions are within bounds
            if new_col < 0 or new_col >= 10 or new_row < 0 or new_row >= 10:
                self.snap_back(item)
                self.clear_highlights()
                return

            start_row, start_col = self.drag_data['start_row'], self.drag_data['start_col']

            # Process the move using GameLogic
            result = self.game_logic.process_move(start_row, start_col, new_row, new_col)

            if result.get('action') == 'game_over':
                winner = result['winner']
                self.game_logic.game_over = True
                self.update_window_title()
                self.render_board()
                self.show_game_over(winner)
            else:
                action = result.get('action')
                if action == 'normal_move':
                    # Move the piece on the board
                    self.move_piece(item, new_row, new_col)
                    self.update_window_title()
                    self.render_board()
                elif action == 'capture_move':
                    # Move the piece and remove the enemy piece
                    self.remove_piece_at(new_row, new_col)
                    self.move_piece(item, new_row, new_col)
                    self.update_window_title()
                    self.render_board()
                elif action == 'catapult_shot':
                    # Remove the enemy piece, snap back the moving piece
                    self.remove_piece_at(new_row, new_col)
                    self.snap_back(item)
                    self.update_window_title()
                    self.render_board()
                elif action == 'invalid':
                    # Invalid move, snap back
                    self.snap_back(item)

            self.clear_highlights()

        self.canvas.tag_bind(piece_id, "<Button-1>", on_drag_start)
        self.canvas.tag_bind(piece_id, "<B1-Motion>", on_drag_motion)
        self.canvas.tag_bind(piece_id, "<ButtonRelease-1>", on_drag_release)

    def move_piece(self, item, new_row, new_col):
        target_x = new_col * self.cell_size + self.cell_size / 2
        target_y = new_row * self.cell_size + self.cell_size / 2
        self.canvas.coords(item, target_x, target_y)
        self.pieces[item] = (new_row, new_col)

    def snap_back(self, item):
        start_row, start_col = self.drag_data['start_row'], self.drag_data['start_col']
        target_x = start_col * self.cell_size + self.cell_size / 2
        target_y = start_row * self.cell_size + self.cell_size / 2
        self.canvas.coords(item, target_x, target_y)

    def remove_piece_at(self, row, col):
        items_to_delete = [k for k, v in self.pieces.items() if v == (row, col)]
        for item_to_delete in items_to_delete:
            self.canvas.delete(item_to_delete)
            del self.pieces[item_to_delete]

    def highlight_moves(self, start_row, start_col):
        self.highlighted_cells = [] 
        start_pos = f"{chr(start_col + ord('a'))}{9 - start_row}"
        for move in self.game_logic.valid_moves:
            if move.startswith(start_pos + "-"):
                end_pos = move.split("-")[1]
                end_col = ord(end_pos[0]) - ord('a')
                end_row_num = int(end_pos[1:])
                end_row = 9 - end_row_num

                target_piece = self.game_logic.get_piece_at(end_row, end_col)
                if target_piece:
                    if self.game_logic.is_enemy_piece(target_piece):
                        # Attack move (capture or catapult shot)
                        color = 'red'
                    else:
                        # Friendly piece, should not happen in valid moves, but skip if it does
                        continue
                else:
                    # Normal move to empty cell
                    color = 'yellow'

                # Highlight the cell
                x1 = end_col * self.cell_size
                y1 = end_row * self.cell_size
                x2 = x1 + self.cell_size
                y2 = y1 + self.cell_size
                highlight_id = self.canvas.create_rectangle(
                    x1, y1, x2, y2, fill=color, stipple='gray50', tags='highlight')
                self.highlighted_cells.append(highlight_id)

    def clear_highlights(self):
        for item in self.highlighted_cells:
            self.canvas.delete(item)
        self.highlighted_cells = []

    def show_game_over(self, winner):
        # Disable interaction
        self.canvas.unbind("<Button-1>")
        self.canvas.unbind("<B1-Motion>")
        self.canvas.unbind("<ButtonRelease-1>")

        # Display game over message
        self.canvas.create_text(
            250, 250, text=f"{winner} Wins!", font=('Helvetica', 36), fill='gold', tags='game_over'
        )

        # Start confetti animation
        self.confetti_particles = []
        for _ in range(100):
            x = random.randint(0, 500)
            y = random.randint(-500, 0)
            color = random.choice(['red', 'blue', 'green', 'yellow', 'purple', 'orange'])
            size = random.randint(5, 10)
            particle = self.canvas.create_oval(
                x, y, x + size, y + size, fill=color, outline=''
            )
            self.confetti_particles.append({'id': particle, 'x': x, 'y': y, 'dy': random.uniform(2, 5)})

        self.animate_confetti()

    def animate_confetti(self):
        for particle in self.confetti_particles:
            particle['y'] += particle['dy']
            if particle['y'] > 500:
                particle['y'] = random.randint(-500, 0)
                particle['x'] = random.randint(0, 500)
            self.canvas.coords(
                particle['id'],
                particle['x'], particle['y'],
                particle['x'] + 5, particle['y'] + 5
            )
        self.root.after(50, self.animate_confetti)
