class FENParser:
    
    def parse_board_string(board_string):
        board_rows = board_string.split('/')
        board = []
        for row in board_rows:
            board_row = []
            i = 0
            while i < len(row):
                if row[i].isdigit():
                    num = ''
                    while i < len(row) and row[i].isdigit():
                        num += row[i]
                        i += 1
                    num_empty = int(num)
                    board_row.extend([''] * num_empty)
                else:
                    board_row.append(row[i])
                    i += 1
            board.append(board_row)
        return board

    def generate_board_string(board):
        board_rows = []
        for row in board:
            row_str = ''
            empty_count = 0
            for cell in row:
                if cell == '':
                    empty_count += 1
                else:
                    if empty_count > 0:
                        row_str += str(empty_count)
                        empty_count = 0
                    row_str += cell
            if empty_count > 0:
                row_str += str(empty_count)
            board_rows.append(row_str)
        return '/'.join(board_rows)
