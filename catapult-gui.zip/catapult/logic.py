import subprocess
import os
from catapult.parser import FENParser

# Global variable for executable path
EXECUTABLE_PATH = "./bin/catapult"

if not os.path.isfile(EXECUTABLE_PATH):
    raise FileNotFoundError(f"The executable file '{EXECUTABLE_PATH}' was not found. Please ensure the path is correct.")

class GameLogic:
    def __init__(self, board_string, current_player):
        self.board_string = board_string
        print(f"Start board: {self.board_string}")
        self.current_player = current_player
        self.board = FENParser.parse_board_string(self.board_string)
        self.valid_moves = self.get_valid_moves()
        self.game_over = False

    def get_valid_moves(self):
        try:
            result = subprocess.run(
                [EXECUTABLE_PATH, self.board_string, self.current_player],
                capture_output=True, text=True, check=True
            )
            valid_moves_str = result.stdout.strip()
            if valid_moves_str.startswith('[') and valid_moves_str.endswith(']'):
                valid_moves_str = valid_moves_str[1:-1]
            valid_moves = [move.strip() for move in valid_moves_str.split(',')]
            player_full = 'black' if self.current_player == 'b' else 'white'
            moves_display = '[' + ', '.join(valid_moves) + ']'
            print(f"Valid moves for {player_full} player: {moves_display}")
            return valid_moves
        except subprocess.CalledProcessError as e:
            print(f"Error executing the external program: {e}")
            return []
        except ValueError as e:
            print(f"Error parsing the output: {e}")
            return []

    def update_board(self, start_row, start_col, new_row, new_col):
        piece = self.board[start_row][start_col]
        self.board[start_row][start_col] = ''
        self.board[new_row][new_col] = piece
        self.board_string = FENParser.generate_board_string(self.board)
        print(f"Updated board: {self.board_string}")

    def switch_player(self):
        self.current_player = 'b' if self.current_player == 'w' else 'w'

    def get_piece_owner(self, piece_char):
        piece_to_player = {
            'B': 'b',  # Black flag
            'G': 'b',  # Black general
            'b': 'b',  # Black knight
            'W': 'w',  # White flag
            'g': 'w',  # White general
            'w': 'w'   # White knight
        }
        return piece_to_player.get(piece_char)

    def is_enemy_piece(self, piece_char):
        piece_owner = self.get_piece_owner(piece_char)
        if piece_owner is None:
            return False
        return piece_owner != self.current_player

    def get_piece_at(self, row, col):
        if 0 <= row < 10 and 0 <= col < 10:
            return self.board[row][col]
        return None

    def is_adjacent(self, start_row, start_col, end_row, end_col):
        return max(abs(end_row - start_row), abs(end_col - start_col)) == 1

    def check_game_over(self):
        # Check if 'W' or 'B' is missing from the board
        white_flag_exists = any('W' in row for row in self.board)
        black_flag_exists = any('B' in row for row in self.board)
        white_general_exists = any('g' in row for row in self.board)
        black_general_exists = any('G' in row for row in self.board)
        if not white_flag_exists or not white_general_exists:
            self.game_over = True
            return 'Black'
        elif not black_flag_exists or not black_general_exists:
            self.game_over = True
            return 'White'
        return None

    def process_move(self, start_row, start_col, new_row, new_col):
        # Determine the move notation
        start_pos = f"{chr(start_col + ord('a'))}{9 - start_row}"
        end_pos = f"{chr(new_col + ord('a'))}{9 - new_row}"
        move = f"{start_pos}-{end_pos}"

        # Check if the move is valid
        if move in self.valid_moves:
            target_piece = self.get_piece_at(new_row, new_col)
            if target_piece:
                if self.is_enemy_piece(target_piece):
                    if self.is_adjacent(start_row, start_col, new_row, new_col):
                        # Capture: adjacent enemy piece
                        print(f"Capture: {move}")
                        self.update_board(start_row, start_col, new_row, new_col)
                        self.switch_player()
                        self.valid_moves = self.get_valid_moves()
                        # Check for game over
                        winner = self.check_game_over()
                        if winner:
                            return {'action': 'game_over', 'winner': winner}
                        return {
                            'action': 'capture_move',
                            'move_piece': True,
                            'remove_piece': (new_row, new_col),
                            'switch_player': True
                        }
                    else:
                        # Catapult shot if non-adjacent enemy piece
                        print(f"Catapult shot: {move}")
                        self.board[new_row][new_col] = ''
                        self.switch_player()
                        self.valid_moves = self.get_valid_moves()
                        # Check for game over
                        winner = self.check_game_over()
                        if winner:
                            return {'action': 'game_over', 'winner': winner}
                        return {
                            'action': 'catapult_shot',
                            'move_piece': False,
                            'remove_piece': (new_row, new_col),
                            'switch_player': True
                        }
            else:
                # Normal move to empty cell
                print(f"Move: {move}")
                self.update_board(start_row, start_col, new_row, new_col)
                self.switch_player()
                self.valid_moves = self.get_valid_moves()
                return {
                    'action': 'normal_move',
                    'move_piece': True,
                    'switch_player': True
                }
        else:
            # Invalid move
            print(f"Invalid: {move}")
            return {'action': 'invalid'}
